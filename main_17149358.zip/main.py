import random
import subprocess
import platform
import ipaddress
import csv

def is_private_ip(ip_str):
    """Проверка, является ли IP частным."""
    ip = ipaddress.IPv4Address(ip_str)
    return ip.is_private

def generate_random_ip():
    """Генерация случайного IP-адреса, исключая частные диапазоны."""
    while True:
        ip_parts = [random.randint(1, 254) for _ in range(4)]
        ip_str = ".".join(map(str, ip_parts))
        if not is_private_ip(ip_str):
            return ip_str

def check_ping(ip):
    """Проверка доступности IP-адреса с помощью ping."""
    param = "-n" if platform.system().lower() == "windows" else "-c"
    try:
        subprocess.check_output(['ping', param, '1', ip], stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        return "Доступен"
    except subprocess.CalledProcessError:
        return "Недоступен"

def sum_match(ip):
    """Проверка признака: сумма A+B == сумма C+D."""
    parts = list(map(int, ip.split('.')))
    return sum(parts[:2]) == sum(parts[2:])

def main(n=50, output_file="results.csv"):
    results = []
    for _ in range(n):
        ip = generate_random_ip()
        if sum_match(ip):
            status = check_ping(ip)
            results.append((ip, status, "Сумма A+B == C+D"))

    # Сохраняем результаты в CSV-файл
    with open(output_file, mode='w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        writer.writerow(["IPv4-адрес", "Доступность", "Признак совпадения"])
        writer.writerows(results)

    print(f"Готово! Результаты сохранены в файл: {output_file}")

if __name__ == "__main__":
    main()
