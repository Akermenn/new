import psycopg2
from db_config import get_connection

def init_data():
    conn = get_connection()
    cur = conn.cursor()

    cur.execute("INSERT INTO participant (name, email) VALUES ('Иванов И.И.', 'ivanov@example.com');")
    cur.execute("INSERT INTO participant (name, email) VALUES ('Петров П.П.', 'petrov@example.com');")

    cur.execute("INSERT INTO venue (name, address, capacity) VALUES ('Дом молодёжи', 'ул. Ленина, 12', 30);")
    cur.execute("INSERT INTO venue (name, address, capacity) VALUES ('Технопарк', 'пр. Науки, 5', 50);")

    cur.execute("""INSERT INTO event (name, description, age_limit, start_time, end_time, venue_id)
                   VALUES ('Python Day', 'Всё про Python', 14, '2025-04-14 10:00', '2025-04-14 14:00', 1);""")

    cur.execute("""INSERT INTO event (name, description, age_limit, start_time, end_time, venue_id)
                   VALUES ('AI Форум', 'Будущее ИИ', 18, '2025-04-15 12:00', '2025-04-15 16:00', 2);""")

    conn.commit()
    conn.close()

if __name__ == '__main__':
    init_data()