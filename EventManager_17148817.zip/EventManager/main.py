from db_config import get_connection

def get_upcoming_events():
    conn = get_connection()
    cur = conn.cursor()
    cur.execute("""
        SELECT e.name, e.description, e.start_time, v.name, v.address, 
        v.capacity - COUNT(r.id) as free_spots, e.age_limit
        FROM event e
        JOIN venue v ON e.venue_id = v.id
        LEFT JOIN registration r ON r.event_id = e.id
        WHERE e.start_time > NOW()
        GROUP BY e.id, v.id
        ORDER BY e.start_time;
    """)
    events = cur.fetchall()
    conn.close()
    return events

if __name__ == '__main__':
    events = get_upcoming_events()
    for event in events:
        print("Название:", event[0])
        print("Описание:", event[1])
        print("Дата и время:", event[2])
        print("Площадка:", event[3])
        print("Адрес:", event[4])
        print("Свободные места:", event[5])
        print("Возрастной ценз:", event[6])
        print("=" * 40)