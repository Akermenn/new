CREATE TABLE participant (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE
);

CREATE TABLE venue (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    address VARCHAR(255),
    capacity INT
);

CREATE TABLE event (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100),
    description TEXT,
    age_limit INT,
    start_time TIMESTAMP,
    end_time TIMESTAMP,
    venue_id INT REFERENCES venue(id)
);

CREATE TABLE registration (
    id SERIAL PRIMARY KEY,
    participant_id INT REFERENCES participant(id),
    event_id INT REFERENCES event(id),
    UNIQUE (participant_id, event_id)
);